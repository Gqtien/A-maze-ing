DIGIT_GLYPH_H = 5
DIGIT_GLYPH_W = 3

DIGITS: dict[str, list[str]] = {
    "ZERO": [
        "OOO",
        "O.O",
        "O.O",
        "O.O",
        "OOO",
    ],

    "ONE": [
        "OO.",
        ".O.",
        ".O.",
        ".O.",
        "OOO",
    ],

    "TWO": [
        "OOO",
        "..O",
        "OOO",
        "O..",
        "OOO",
    ],

    "THREE": [
        "OOO",
        "..O",
        ".OO",
        "..O",
        "OOO",
    ],

    "FOUR": [
        "O.O",
        "O.O",
        "OOO",
        "..O",
        "..O",
    ],

    "FIVE": [
        "OOO",
        "O..",
        "OOO",
        "..O",
        "OOO",
    ],

    "SIX": [
        "OOO",
        "O..",
        "OOO",
        "O.O",
        "OOO",
    ],

    "SEVEN": [
        "OOO",
        "..O",
        "..O",
        "..O",
        "..O",
    ],

    "EIGHT": [
        "OOO",
        "O.O",
        "OOO",
        "O.O",
        "OOO",
    ],

    "NINE": [
        "OOO",
        "O.O",
        "OOO",
        "..O",
        "OOO",
    ],
}

from typing import NamedTuple
class Pattern:
    """Two-digit pattern"""
    class PatternDigits(NamedTuple):
        """Names of the two Digits enum members for patterns."""
        first: str
        second: str

    def __init__(self, value: str) -> None:
        """Parse value: exactly 2 digits."""
        raw = value.strip()
        if len(raw) != 2:
            raise ValueError(
                f"'PATTERN' must be exactly 2 digits, got {value!r}"
            )
        numbers = [
            "ZERO", "ONE", "TWO", "THREE", "FOUR",
            "FIVE", "SIX", "SEVEN", "EIGHT", "NINE",
        ]
        try:
            first = int(raw[0])
            second = int(raw[1])
            if first not in range(10) or second not in range(10):
                raise ValueError
        except ValueError:
            raise ValueError(f"'PATTERN' digits must be 0-9, got {value!r}")
        self._digits = Pattern.PatternDigits(numbers[first], numbers[second])

    def digits(self) -> "Pattern.PatternDigits":
        """Return the two digit names for this pattern."""
        return self._digits



import random
from enum import Enum


class Wall(Enum):
    """Wall bitmasks."""

    NORTH = 1 << 0
    EAST = 1 << 1
    SOUTH = 1 << 2
    WEST = 1 << 3


class Cell:
    """Maze cell with wall bitmask."""

    def __init__(self, x: int, y: int, walls: int = 0) -> None:
        """Init cell."""
        self.wall: int = walls
        self.x: int = x
        self.y: int = y

    def __repr__(self) -> str:
        """Hex value."""
        return hex(self.wall)[2:].upper()

    def north(self) -> bool:
        """Get north wall."""
        return self.wall & Wall.NORTH.value == Wall.NORTH.value

    def south(self) -> bool:
        """Get south wall."""
        return self.wall & Wall.SOUTH.value == Wall.SOUTH.value

    def east(self) -> bool:
        """Get east wall."""
        return self.wall & Wall.EAST.value == Wall.EAST.value

    def west(self) -> bool:
        """Get west wall."""
        return self.wall & Wall.WEST.value == Wall.WEST.value

    def nw(self) -> bool:
        """North or West."""
        return self.north() or self.west()

    def ne(self) -> bool:
        """North or east."""
        return self.north() or self.east()

    def sw(self) -> bool:
        """South or west."""
        return self.south() or self.west()

    def se(self) -> bool:
        """South or east."""
        return self.south() or self.east()

    def is_full(self) -> bool:
        """Check if every wall is there."""
        return self.east() and self.west() and self.north() and self.south()


class Maze:
    """Maze grid."""

    def __init__(
        self,
        width: int | None,
        height: int | None,
        entry_pos: tuple[int, int] | None,
        exit_pos: tuple[int, int] | None,
        perfect: bool | None = None,
        seed: int | None = None,
        output_file_name: str | None = None,
        pattern: Pattern | None = None,
        algo: str | None = None,
    ) -> None:
        """Maze constructor."""
        self.width: int = width
        self.height: int = height
        self.entry_pos: tuple[int, int] = entry_pos
        self.exit_pos: tuple[int, int] = exit_pos
        self.perfect: bool = True if perfect is None else bool(perfect)
        self._maze: list[list[Cell]] = []
        self.pattern: Pattern = pattern if pattern else Pattern("42")
        self.algo: str = (algo or "backtracking").lower()
        self.seed: int = (
            seed
            if seed is not None
            else random.randint(0, 1_000_000)
        )

        self._generate()

        if output_file_name is not None:
            self.save_to_file(output_file_name)

    def __str__(self) -> str:
        """Ascii minimap."""
        grid = self.to_grid()
        minimap: str = ""
        for line in grid:
            for cell in line:
                minimap += '██' if cell else "  "
            minimap += '\n'
        return minimap

    def __repr__(self) -> str:
        """
            Hex ascii map,
            entry and exit positions,
            shortest valid path from entry to exit.
        """
        ret: str = ""
        for y in range(self.height):
            for x in range(self.width):
                ret += repr(self._maze[y][x])
            ret += "\n"
        ret += "\n"

        for pos in (self.entry_pos, self.exit_pos):
            ret += ",".join(map(str, pos)) + "\n"
        # TODO: the shortest valid path from entry to exit,
        # using the four letters N , E , S , W .
        return ret

    def _generate(self) -> None:
        """Run generation and returns the maze."""
        # NOTE: init maze full of walls (0xF)
        for y in range(self.height):
            row: list[Cell] = []
            for x in range(self.width):
                row.append(Cell(x, y, 0xF))
            self._maze.append(row)

        rng = random.Random(self.seed)

        match self.algo:
            case "prim":
                self._prim(rng)
            case _:
                self._backtracking(rng)

        if not self.perfect:
            self._add_exit_loop(rng)

    def get_pattern_cells(self) -> set[Cell]:
        """Return cells to mark the 42 in the center."""
        d = self.pattern.digits()
        pattern_first: list[str] = DIGITS[d.first]
        pattern_second: list[str] = DIGITS[d.second]

        digit_height: int = len(pattern_first)
        digit_width: int = len(pattern_first[0]) if pattern_first else 0
        total_width: int = digit_width * 2 + 1

        # exit if maze is too small
        if self.width < total_width or self.height < digit_height:
            return set()

        top: int = (self.height - digit_height) // 2
        left_first: int = (self.width - total_width) // 2
        left_second: int = left_first + digit_width + 1

        cells: set[Cell] = set()

        for pattern, left in (
            (pattern_first, left_first),
            (pattern_second, left_second),
        ):
            for dy, row in enumerate(pattern):
                for dx, ch in enumerate(row):
                    if ch != "O":
                        continue
                    x: int = left + dx
                    y: int = top + dy
                    if (x, y) == self.entry_pos or (x, y) == self.exit_pos:
                        continue
                    cells.add(self.get_cell(x, y))

        return cells

    def _backtracking(self, rng: random.Random) -> None:
        """Perfect maze via iterative backtracking."""
        stack: list[Cell] = []
        visited: set[Cell] = self.get_pattern_cells()
        start: Cell = self.get_cell(*self.entry_pos)
        stack.append(start)
        visited.add(start)

        while stack:
            current: Cell = stack[-1]
            neighbors: list[Cell] = self.get_neighbors(current)
            unvisited: list[Cell] = [n for n in neighbors if n not in visited]
            rng.shuffle(unvisited)

            if unvisited:
                neighbor: Cell = unvisited[0]
                self._open_wall_between(current, neighbor)
                visited.add(neighbor)
                stack.append(neighbor)
            else:
                stack.pop()

    def _prim(self, rng: random.Random) -> None:
        """Perfect maze via Prim's algorithm."""
        in_maze: set[Cell] = set(self.get_pattern_cells())
        start: Cell = self.get_cell(*self.entry_pos)
        in_maze.add(start)

        frontier: list[tuple[Cell, Cell]] = []
        for neighbor in self.get_neighbors(start):
            if neighbor not in in_maze:
                frontier.append((start, neighbor))

        while frontier:
            cell_in, cell_out = frontier.pop(rng.randint(0, len(frontier) - 1))
            if cell_out in in_maze:
                continue
            self._open_wall_between(cell_in, cell_out)
            in_maze.add(cell_out)
            for neighbor in self.get_neighbors(cell_out):
                if neighbor not in in_maze:
                    frontier.append((cell_out, neighbor))

    def _degree(self, c: Cell) -> int:
        """Number of open sides."""
        return (
            int(not c.north())
            + int(not c.east())
            + int(not c.south())
            + int(not c.west())
        )

    def _is_open_between(self, a: Cell, b: Cell) -> bool:
        """
            True if there is already an opening between adjacent cells a and b.
        """
        dx, dy = b.x - a.x, b.y - a.y
        match dx, dy:
            case 1, 0:
                return (
                    (a.wall & Wall.EAST.value) == 0
                    and (b.wall & Wall.WEST.value) == 0
                )
            case -1, 0:
                return (
                    (a.wall & Wall.WEST.value) == 0
                    and (b.wall & Wall.EAST.value) == 0
                )
            case 0, 1:
                return (
                    (a.wall & Wall.SOUTH.value) == 0
                    and (b.wall & Wall.NORTH.value) == 0
                )
            case 0, -1:
                return (
                    (a.wall & Wall.NORTH.value) == 0
                    and (b.wall & Wall.SOUTH.value) == 0
                )
        return False

    def _add_exit_loop(self, rng: random.Random) -> None:
        """Add one shortcut from the exit."""
        exit_cell = self.get_cell(*self.exit_pos)
        blocked = self.get_pattern_cells()
        cur, prev = exit_cell, None

        for _ in range(self.width * self.height):
            neighbors = [
                n for n in self.get_neighbors(cur)
                if n not in blocked and n != prev
            ]
            rng.shuffle(neighbors)
            if not neighbors:
                break
            nxt = neighbors[0]
            if not self._is_open_between(cur, nxt):
                self._open_wall_between(cur, nxt)
            prev, cur = cur, nxt
            if self._degree(cur) >= 2:
                return

        candidates = [
            n for n in self.get_neighbors(exit_cell)
            if n not in blocked and not self._is_open_between(exit_cell, n)
        ]
        if candidates:
            self._open_wall_between(exit_cell, rng.choice(candidates))

    def _open_wall_between(self, cell1: Cell, cell2: Cell) -> None:
        """Open path between two adjacent cells."""
        dx = cell2.x - cell1.x
        dy = cell2.y - cell1.y
        match dx, dy:
            case 1, 0:
                cell1.wall &= ~Wall.EAST.value
                cell2.wall &= ~Wall.WEST.value
            case 0, 1:
                cell1.wall &= ~Wall.SOUTH.value
                cell2.wall &= ~Wall.NORTH.value
            case -1, 0:
                cell1.wall &= ~Wall.WEST.value
                cell2.wall &= ~Wall.EAST.value
            case 0, -1:
                cell1.wall &= ~Wall.NORTH.value
                cell2.wall &= ~Wall.SOUTH.value

    def get_neighbors(self, cell: Cell) -> list[Cell]:
        """Return list of adjacent cells."""
        ret: list[Cell] = []
        for dx, dy in (-1, 0), (1, 0), (0, 1), (0, -1):
            nx, ny = cell.x + dx, cell.y + dy
            if nx < 0 or ny < 0 or nx >= self.width or ny >= self.height:
                continue
            ret.append(self._maze[ny][nx])
        return ret

    def get_cell(self, x: int, y: int) -> Cell:
        """Return cell at (x, y)."""
        return self._maze[y][x]

    def get_maze(self) -> list[list[Cell]]:
        """Return maze rows."""
        return self._maze

    def to_grid(self) -> list[list[bool]]:
        """Convert maze to a bool grid."""
        gw = self.width * 2 + 1
        gh = self.height * 2 + 1

        # start full of walls
        grid: list[list[bool]] = [[True] * gw for _ in range(gh)]

        for y in range(self.height):
            for x in range(self.width):
                cell = self.get_cell(x, y)

                cx = 2 * x + 1
                cy = 2 * y + 1

                # cell center is always a path
                grid[cy][cx] = False

                # open passages according to missing walls
                if not cell.north():
                    grid[cy - 1][cx] = False
                if not cell.south():
                    grid[cy + 1][cx] = False
                if not cell.west():
                    grid[cy][cx - 1] = False
                if not cell.east():
                    grid[cy][cx + 1] = False

        return grid

    def pattern_core_to_grid(self) -> set[tuple[int, int]]:
        """Return grid coords of pattern cells and links only (no outline)."""
        pattern_cells = self.get_pattern_cells()
        out: set[tuple[int, int]] = set()
        for c in pattern_cells:
            out.add((2 * c.x + 1, 2 * c.y + 1))
            for n in self.get_neighbors(c):
                if n in pattern_cells:
                    out.add((c.x + n.x + 1, c.y + n.y + 1))
        return out

    def pattern_to_grid(self) -> set[tuple[int, int]]:
        """Return grid coords of pattern cells, links, and 1 cell border."""
        out = self.pattern_core_to_grid()
        gw, gh = 2 * self.width + 1, 2 * self.height + 1
        for (gx, gy) in list(out):
            for dgx, dgy in (
                (1, 0), (-1, 0), (0, 1), (0, -1),
                (1, 1), (-1, 1), (1, -1), (-1, -1),
            ):
                ngx, ngy = gx + dgx, gy + dgy
                if 0 <= ngx < gw and 0 <= ngy < gh:
                    out.add((ngx, ngy))
        return out

    def save_to_file(self, filename: str) -> None:
        """Save the hex representation of the maze to file."""
        try:
            with open(filename, "w") as file:
                file.write(repr(self))
        except Exception as e:
            print(f"Error while trying to save maze to {filename}: {e}")


__all__ = [\"Maze\"]
